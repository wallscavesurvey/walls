//========================================================================================
//
//  $File: //ai/cs6/devtech/sdk/public/samplecode/MultiArrowTool/Resources/MultiArrowTool.r $
//
//  $Revision: #3 $
//
//  Copyright 1987 Adobe Systems Incorporated. All rights reserved.
//
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or
//  distribution of it requires the prior written permission of Adobe.
//
//========================================================================================

#define PIPL_PLUGIN_NAME "MultiArrowTool"
#include "Plugin.r"

#include "Types.r"

read 'PNGI' (16051, "HEADARROWTOOL", purgeable)  "HeadArrowTool.png";
read 'PNGI' (16052, "TAILARROWTOOL", purgeable)  "TailArrowTool.png";
read 'PNGI' (16053, "BOTHENDSARROWTOOL", purgeable)  "BothEndsArrowTool.png";
read 'PNGI' (16054, "STRAIGHTLINETOOL", purgeable)  "StraightLineTool.png";
read 'PNGI' (16055, "HEADARROWTOOLDARK", purgeable)  "HeadArrowToolDark.png";
read 'PNGI' (16056, "TAILARROWTOOLDARK", purgeable)  "TailArrowToolDark.png";
read 'PNGI' (16057, "BOTHENDSARROWTOOLDARK", purgeable)  "BothEndsArrowToolDark.png";
read 'PNGI' (16058, "STRAIGHTLINETOOLDARK", purgeable)  "StraightLineToolDark.png";
/** Head Arrow Tool cursor.
*/
/*resource 'CURS' (16001) {
        $"00 00 00 00"
		$"18 00 3C 00"
		$"1E 00 0F 00"
		$"07 80 03 C8"
        $"01 E8 00 FC"
		$"00 7C 00 7C"
		$"01 FE 00 3E"
		$"00 06 00 00",
        $"00 00 00 00"
		$"18 00 3C 00"
		$"1E 00 0F 00"
		$"07 80 03 C8"
        $"01 E8 00 FC"
		$"00 7C 00 7C"
		$"01 FE 00 3E"
		$"00 06 00 00",
        {14, 14}
};
*/
/** Tail Arrow Tool cursor.
*/
/*
resource 'CURS' (16002) {
        $"00 00 00 00"
		$"30 00 3E 00"
		$"3F C0 1F 00"
		$"1F 00 1F 80"
        $"0B C0 09 E0"
		$"00 F0 00 78"
		$"00 3C 00 1E"
		$"00 0C 00 00",
        $"00 00 00 00"
		$"30 00 3E 00"
		$"3F C0 1F 00"
		$"1F 00 1F 80"
        $"0B C0 09 E0"
		$"00 F0 00 78"
		$"00 3C 00 1E"
		$"00 0C 00 00",
        {2, 2}
};
*/
/** Both Ends Arrow Tool cursor.
*/
/*
resource 'CURS' (16003) {
        $"00 00 7E 00"
		$"78 00 78 00"
		$"7C 00 5E 00"
		$"4F 00 07 80"
        $"03 C0 01 E4"
		$"00 F4 00 7C"
		$"00 3C 00 3C"
		$"00 FC 00 00",
        $"00 00 3F 00"
		$"3C 00 3C 00"
		$"3E 00 2F 00"
		$"27 80 03 C0"
        $"01 E0 00 F2"
		$"00 7A 00 3E"
		$"00 1E 00 1E"
		$"00 7E 00 00",
        {1, 1}
};
*/
/** Straight Line Tool cursor.
*/
/*
resource 'CURS' (16004) {
        $"00 00 00 00"
		$"00 00 01 00"
		$"01 00 01 00"
		$"03 80 1F F0"
        $"03 80 01 00"
		$"01 00 01 00"
		$"00 00 00 00"
		$"00 00 00 00",
        $"00 00 00 00"
		$"00 00 01 00"
		$"01 00 01 00"
		$"03 80 1F F0"
        $"03 80 01 00"
		$"01 00 01 00"
		$"00 00 00 00"
		$"00 00 00 00",
        {7, 7}
};
*/
