//========================================================================================
//  
//  $File: //ai/cs6/devtech/sdk/public/samplecode/MultiArrowTool/Source/MultiArrowToolID.h $
//
//  $Revision: #3 $
//
//  Copyright 1987 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#ifndef __MULTIARROWTOOLID_H__
#define __MULTIARROWTOOLID_H__

#define kMultiArrowToolPluginName	"MultiArrowTool"

#define kCursorID				16000

#define kHeadArrowToolIconResID			16051
#define kTailArrowToolIconResID			16052
#define kBothEndsArrowToolIconResID		16053
#define kStraightLineToolIconResID		16054

#define kHeadArrowToolIconDarkResID		16055
#define kTailArrowToolIconDarkResID		16056
#define kBothEndsArrowToolIconDarkResID	16057
#define kStraightLineToolIconDarkResID	16058

#endif // End MultiArrowToolID.h
