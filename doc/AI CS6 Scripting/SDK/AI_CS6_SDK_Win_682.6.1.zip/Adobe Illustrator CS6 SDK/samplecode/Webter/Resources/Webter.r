//========================================================================================
//  
//  $File: //ai/cs6/devtech/sdk/public/samplecode/Webter/Resources/Webter.r $
//
//  $Revision: #2 $
//
//  Copyright 1987 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#define PIPL_PLUGIN_NAME "Webter"
#include "Plugin.r"

#include "Types.r"
#include "WebterID.h"

read 'PNGI' (1001, "ID_DIALOG_ICON", purgeable)  "WebterIcon.png";
read 'PNGI' (1002, "ID_DIALOG_ICON_ROLLOVER", purgeable)  "WebterIconRollover.png";

