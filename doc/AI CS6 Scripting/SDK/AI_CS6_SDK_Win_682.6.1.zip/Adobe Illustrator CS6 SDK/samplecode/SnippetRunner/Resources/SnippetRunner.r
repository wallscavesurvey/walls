#define PIPL_PLUGIN_NAME "SnippetRunner"
#include "Plugin.r"

#include "SnippetRunnerID.h"

#include "Types.r"

/** Parameter prompt dialog.
*/
resource 'DLOG' (kSnippetRunnerPromptDialogID, kSnippetRunnerPromptDialogName, purgeable) { 
	//{200, 200, 400, 500},
	{200, 200, 330, 600}, 
	5, // movableDBoxProc
	visible, 
	goAway, 
	0x0, 
	kSnippetRunnerPromptDialogID, 
	kSnippetRunnerPromptDialogName, 
	0x0 // noAutoCenter 
}; 

/** List of controls in parameter prompt dialog.
*/
resource 'DITL' (kSnippetRunnerPromptDialogID, kSnippetRunnerPromptDialogName, purgeable) {
	{
		{15,315,35,395}, // top, left, bottom, right
		Button {
			enabled,
			"OK"
		},
		{50,315,70,395}, // top, left, bottom, right
		Button {
			enabled,
			"Cancel"
		},
		{5,5,40,300}, // top, left, bottom, right
		StaticText {
			enabled,
			"Prompt: "
		},
		{50,5,70,300}, // top, left, bottom, right
		EditText {
			enabled,
			""
		},
		{50,5,70,300}, // top, left, bottom, right
		Control {
			enabled,
			kSnippetRunnerPromptDialogID+kSnippetRunnerParameterChoiceItemID
		},
		{90,5,110,175}, // top, left, bottom, right
		StaticText {
			enabled,
			"Type: "
		},
	}
};

resource 'CNTL' (kSnippetRunnerPromptDialogID+kSnippetRunnerParameterChoiceItemID, "SnippetRunnerParameterChoice", purgeable) {
	{0,0,14,170},
	0,
	invisible,
	0,
	0,
	1008, // kADMPopupListType ProcID
	0,
	""
};



