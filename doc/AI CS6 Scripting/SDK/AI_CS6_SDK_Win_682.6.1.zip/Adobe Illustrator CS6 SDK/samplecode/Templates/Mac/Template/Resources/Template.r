#include "[PROJECT_NAME]ID.h"
#define PIPL_PLUGIN_NAME k[PROJECT_NAME]PluginName

#include "Plugin.r"

#include "Types.r"
