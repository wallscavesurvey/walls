#ifndef __[PROJECT_NAME]_H__
#define __[PROJECT_NAME]_H__

#define k[PROJECT_NAME]PluginName	"[PROJECT_NAME]"

#endif // End [PROJECT_NAME]ID.h
