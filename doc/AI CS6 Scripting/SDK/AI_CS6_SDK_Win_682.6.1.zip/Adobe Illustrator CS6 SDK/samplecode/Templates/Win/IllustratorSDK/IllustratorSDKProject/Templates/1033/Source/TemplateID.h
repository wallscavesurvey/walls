#ifndef __[!output PROJECT_NAME]ID_H__
#define __[!output PROJECT_NAME]ID_H__

#define k[!output PROJECT_NAME]PluginName	"[!output PROJECT_NAME]"

#endif // End [!output PROJECT_NAME]ID.h
