//========================================================================================
//  
//  $File: //ai/cs6/devtech/sdk/public/samplecode/TransformButtons/Resources/TransformButtons.r $
//
//  $Revision: #2 $
//
//  Copyright 1987 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#define PIPL_PLUGIN_NAME "TransformButtons"
#include "Plugin.r"
#include "TransformButtonsID.h"
#include "Types.r"

read 'PNGI' (1001, "TransformButtonsRotateCCWIcon", purgeable) "TransformButtonsRotateCCWIcon.png";
read 'PNGI' (1002, "TransformButtonsRotateCWIcon", purgeable) "TransformButtonsRotateCWIcon.png";
read 'PNGI' (1003, "TransformButtonsScaleUpIcon", purgeable) "TransformButtonsScaleUpIcon.png";
read 'PNGI' (1004, "TransformButtonsScaleDownIcon", purgeable) "TransformButtonsScaleDownIcon.png";
read 'PNGI' (1005, "TransformButtonsUpArrowIcon", purgeable) "TransformButtonsUpArrowIcon.png";
read 'PNGI' (1006, "TransformButtonsDownArrowIcon", purgeable) "TransformButtonsDownArrowIcon.png";
read 'PNGI' (1007, "TransformButtonsLeftArrowIcon", purgeable) "TransformButtonsLeftArrowIcon.png";
read 'PNGI' (1008, "TransformButtonsRightArrowIcon", purgeable) "TransformButtonsRightArrowIcon.png";
read 'PNGI' (1009, "TransformButtonsIcon", purgeable)  "TransformButtonsIcon.png";
read 'PNGI' (1010, "TransformButtonsIconRollover", purgeable)  "TransformButtonsIconRollover.png";

/** TransformButtons dialog resource.
*/
resource 'DLOG' (kTransformButtonsDialogID, kTransformButtonsDialogName, purgeable) {
	{100, 200, 160, 390}, // top, left, bottom, right
	1991, // floatZoomGrowProc
	visible, // drawn on screen immediately
	goAway, // has close button
	0x0, // application options
	kTransformButtonsDialogID, // resource ID
	kTransformButtonsDialogName, // dialog title
	0x0 // dialog positioning noAutoCenter
};

/** List of items in TransformButtons dialog
*/
resource 'DITL' (kTransformButtonsDialogID, kTransformButtonsDialogName, purgeable) {
	{
		// 1. Rotate 90 CCW button.
		{16, 16, 35, 44}, // top, left, bottom, right
		Control {
			enabled,
			kRotateCCWID
		},
		
		// 2. Rotate 90 CW button.
		{16, 48, 35, 76}, // top, left, bottom, right
		Control {
			enabled,
			kRotateCWID
		},
		
		// 3. Scale up button.
		{40, 16, 59, 44}, // top, left, bottom, right
		Control {
			enabled,
			kScaleUpID
		},
		
		// 4. Scale down button.
		{40, 48, 59, 76}, // top, left, bottom, right
		Control {
			enabled,
			kScaleDownID
		},
		
		// 5. Translate up button.
		{16, 128, 35, 156}, // top, left, bottom, right
		Control {
			enabled,
			kTranslateUpID
		},
		
		// 6. Translate down button.
		{40, 128, 59, 156}, // top, left, bottom, right
		Control {
			enabled,
			kTranslateDownID
		},
		
		// 7. Translate left button.
		{28, 96, 47, 124}, // top, left, bottom, right
		Control {
			enabled,
			kTranslateLeftID
		},
		
		// 8. Translate right button.
		{28, 160, 47, 188}, // top, left, bottom, right
		Control {
			enabled,
			kTranslateRightID
		},
		
		// 9. Static text "One Click Transforms".
		{1, 3, 16, 144}, // top, left, bottom, right
		StaticText{
			disabled,
			"One Click Transforms"
		},
	}
};

/** TransformButtons rotate CCW button control.
*/
resource 'CNTL' (kRotateCCWID, purgeable) {
	{16, 16, 35, 44}, // top, left, bottom, right
	1001, // Initial icon ID
	visible, // Initially visible
	1001, // Icon ID
	1001, // Icon ID
	16320, // ProcID
	0,
	""
};

/** TransformButtons rotate CW button control.
*/
resource 'CNTL' (kRotateCWID, purgeable) {
	{16, 48, 35, 76}, // top, left, bottom, right
	1002, // Initial icon ID
	visible, // Initially visible
	1002, // Icon ID
	1002, // Icon ID
	16320, // ProcID
	0,
	""
};

/** TransformButtons scale up button control.
*/
resource 'CNTL' (kScaleUpID, purgeable) {
	{40, 16, 59, 44}, // top, left, bottom, right
	1003, // Initial icon ID
	visible, // Initially visible
	1003, // Icon ID
	1003, // Icon ID
	16320, // ProcID
	0,
	""
};

/** TransformButtons scale down button control.
*/
resource 'CNTL' (kScaleDownID, purgeable) {
	{40, 48, 59, 76}, // top, left, bottom, right
	1004, // Initial icon ID
	visible, // Initially visible
	1004, // Icon ID
	1004, // Icon ID
	16320, // ProcID
	0,
	""
};

/** TransformButtons translate up button control.
*/
resource 'CNTL' (kTranslateUpID, purgeable) {
	{16, 128, 35, 156}, // top, left, bottom, right
	1005, // Initial icon ID
	visible, // Initially visible
	1005, // Icon ID
	1005, // Icon ID
	16320, // ProcID
	0,
	""
};

/** TransformButtons translate down button control.
*/
resource 'CNTL' (kTranslateDownID, purgeable) {
	{40, 128, 59, 156}, // top, left, bottom, right
	1006, // Initial icon ID
	visible, // Initially visible
	1006, // Icon ID
	1006, // Icon ID
	16320, // ProcID
	0,
	""
};

/** TransformButtons translate left button control.
*/
resource 'CNTL' (kTranslateLeftID, purgeable) {
	{28, 96, 47, 124}, // top, left, bottom, right
	1007, // Initial icon ID
	visible, // Initially visible
	1007, // Icon ID
	1007, // Icon ID
	16320, // ProcID
	0,
	""
};

/** TransformButtons translate right button control.
*/
resource 'CNTL' (kTranslateRightID, purgeable) {
	{28, 160, 47, 188}, // top, left, bottom, right
	1008, // Initial icon ID
	visible, // Initially visible
	1008, // Icon ID
	1008, // Icon ID
	16320, // ProcID
	0,
	""
};

/** TransformButtons dialog menu.
*/
resource 'MENU' (kTransformButtonsDialogMenuID) {
	kTransformButtonsDialogMenuID,
	textMenuProc,
	-1,
	enabled,
	"TransformButtons panel menu",
	{
		"Repeat Transform",			noIcon, noKey, noMark, plain;
		"-",						noIcon, noKey, noMark, plain;
		"Options",					noIcon, noKey, noMark, plain;
	}
};
