//========================================================================================
//  
//  $File: //ai/cs6/devtech/sdk/public/samplecode/MarkedObjects/Resources/MarkedObjects.r $
//
//  $Revision: #2 $
//
//  Copyright 1987 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#define PIPL_PLUGIN_NAME "MarkedObjects"
#include "Plugin.r"

#include "MarkedObjectID.h"

#include "Types.r"

read 'PNGI' (16050, "MARKEDOBJECTSTOOL") "MarkedObjectsTool.png";
read 'PNGI' (16051, "MARKEDOBJECTSDARKMTOOL", purgeable)  "MarkedObjectsIconRollover.png";
