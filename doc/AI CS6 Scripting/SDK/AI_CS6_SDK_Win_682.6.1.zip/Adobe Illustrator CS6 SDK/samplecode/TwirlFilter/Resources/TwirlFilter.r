//========================================================================================
//  
//  $File: //ai/cs6/devtech/sdk/public/samplecode/TwirlFilter/Resources/TwirlFilter.r $
//
//  $Revision: #2 $
//
//  Copyright 1987 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#define PIPL_PLUGIN_NAME "TwirlFilter"
#include "Plugin.r"

#include "Types.r"
#include "TwirlFilterID.h"

/** Filter strings.
*/
resource 'STR#' (kFilterStrings, "Filter strings") {
	{
		"SDK";
		"Twirl...";
	}
};

/** Twirl filter dialog.
*/
resource 'DLOG' (kTwirlDialogID, kTwirlDialogName, purgeable) {
	{100, 200, 175, 355}, // top, left, bottom, right
	5, // movableDBoxProc
	0x0, // not visible initially
	0x0, // no close button
	0x0, // application options
	kTwirlDialogID, // resource ID
	kTwirlDialogName, // dialog title
	0x0 // dialog positioning noAutoCenter
};

/** List of items in Twirl filter dialog
*/
resource 'DITL' (kTwirlDialogID, kTwirlDialogName, purgeable) {
	{
		// 1. OK button.
		{45, 83, 65, 143}, // top, left, bottom, right
		Button {
			enabled,
			"OK"
		},
		
		// 2. Cancel button.
		{45, 10, 65, 70}, // top, left, bottom, right
		Button {
			enabled,
			"Cancel"
		},
		
		// 3. Edit text for Angle.
		{13, 64, 29, 118}, // top, left, bottom, right
		EditText{
			enabled,
			""
		},
		
		// 4. Static text "Angle:".
		{13, 18, 29, 60}, // top, left, bottom, right
		StaticText {
			disabled,
			"Angle:"
		},
		
		// 5. Static text "".
		{13, 122, 29, 135}, // top, left, bottom, right
		StaticText {
			disabled,
			""
		},
	}
};

/** Twirl filter (few) dialog.
*/
resource 'DLOG' (kTwirlFewDialogID, kTwirlDialogName, purgeable) {
	{100, 200, 230, 355}, // top, left, bottom, right
	5, // movableDBoxProc
	0x0, // not visible initially
	0x0, // no close button
	0x0, // application options
	kTwirlFewDialogID, // resource ID
	kTwirlDialogName, // dialog title
	0x0 // dialog positioning noAutoCenter
};

/** List of items in Twirl filter (few) dialog
*/
resource 'DITL' (kTwirlFewDialogID, kTwirlDialogName, purgeable) {
	{
		// 1. OK button.
		{100, 83, 120, 143}, // top, left, bottom, right
		Button {
			enabled,
			"OK"
		},
		
		// 2. Cancel button.
		{100, 10, 120, 70}, // top, left, bottom, right
		Button {
			enabled,
			"Cancel"
		},
		
		// 3. Edit text for Angle.
		{13, 64, 29, 118}, // top, left, bottom, right
		EditText{
			enabled,
			""
		},
		
		// 4. Static text "Angle:".
		{13, 18, 29, 60}, // top, left, bottom, right
		StaticText {
			disabled,
			"Angle:"
		},
		
		// 5. Static text "".
		{13, 122, 29, 135}, // top, left, bottom, right
		StaticText {
			disabled,
			""
		},
		
		// 6. Static text "Note: ...".
		{39, 17, 86, 139}, // top, left, bottom, right
		StaticText {
			disabled,
			"Note: Twirl works best with lots of anchor points."
		},
	}
};
