Adobe Illustrator CS6 Software Development Kit
ReadMe File

______________________________________________________________________

This file contains the latest information about the Adobe Illustrator
SDK. This information applies to Adobe Illustrator CS6 (16.0).

The SDK enables you to develop software modules that plug into and
extend the functionality of Adobe Illustrator CS6.
______________________________________________________________________

This file has the following sections:
  1. Legal
  2. SDK Documentation Overview
  3. Development Environments
  4. Installing the SDK
  5. What's New
  6. Known Issues
  7. SDK Support and Adobe Partner Programs


***********************************************************
1. Legal
***********************************************************
You may use this SDK only in a manner consistent with the included
End User License Agreement:
  <SDK>/legalnotices/EULAs.pdf


***********************************************************
2. SDK Documentation Overview
***********************************************************
Adobe Illustrator CS6 Getting Started Guide:
  File: <SDK>/docs/guides/getting-started-guide.pdf
  Describes the basics of how to get started developing plug-ins
  for Illustrator CS6 and provides descriptions of the sample
  plug-ins provided with this SDK.

Adobe Illustrator CS6 Porting Guide:
  File: <SDK>/docs/guides/porting-guide.pdf
  Describes how to set up your development environment and port
  existing code to Illustrator CS6. Details changes in the public
  API and other aspects of the SDK since the prior release.

Adobe Illustrator CS6 Programmer's Guide:
  File: <SDK>/docs/guides/programmers-guide.pdf
  Describes the fundamentals of writing plug-ins for Illustrator.

Using the Adobe Text Engine:
  File: <SDK>/docs/guides/using-adobe-text-engine.pdf
  Describes the components of the Illustrator Adobe Text Engine API,
  and provides recipes for creating, editing, deleting, styling and
  iterating text items in a document, with references to sample code
  and the Adobe Illustrator API Reference.

Adobe Illustrator API Reference:
  Reference documentation for the API is provided in two formats:

  File: <SDK>/docs/references/index.chm

    API reference in compiled HTML format, a searchable help file
    To view the contents in Windows, double-click the index.chm
    file icon in Windows Explorer, to open the home page.
    To view the contents in Mac OS, you need a CMH viewer;
    for options, see "Adobe Illustrator CS6 Porting Guide".

  File: <SDK>/docs/references/sdkdocs.tar.gz

    API reference in archive HTML format. After installing the SDK,
    double-click the sdkdocs.tar.gz file to decompress the archive.
    View the HTML documentation in your browser.

API Advisor:
  File: <SDK>/docs/references/apiadvisor-ai15-vs-ai16.html
  Reports class, struct, and file differences between the API included
  with the Illustrator CS5 SDK and this SDK.


***********************************************************
3. Development Environments
***********************************************************
The following platforms are supported for the development of plug-ins
for Illustrator CS6:

Mac OS:
  OS:  Mac OS 10.6
  IDE: Xcode 3.2.5

Windows:
  OS:  Microsoft Windows XP (32-bit) and Microsoft Windows 7
  IDE: Microsoft Visual C++ 10 (Visual Studio 2010 SP1)

For more details, see "Adobe Illustrator CS6 Porting Guide."

***********************************************************
4. Installing the SDK
***********************************************************
To install the SDK, download the pre-configured archive for your
platform from the Adobe Illustrator Developers site:

  http://www.adobe.com/devnet/illustrator/

Start by expanding the archive, then follow the detailed instructions
in "Adobe Illustrator CS6 Getting Started Guide" to set up your
development platform.


***********************************************************
5. What's New
***********************************************************

- New features:

  See details in "Adobe Illustrator CS6 Porting Guide".

- API changes:

  For complete details of API changes, see
   "Adobe Illustrator CS6 Porting Guide" and "API Advisor"

- ADM removed:

  Plug-ins must be ported to some other UI framework to run in
  Illustrator CS6. Note that in Mac OS, ADM used the older Carbon
  framework, while the UI now uses the newer Cocoa framework.
  For more information about how to make this transition, see:
 
     https://developer.apple.com/technologies/mac/cocoa.html

- Sample code changes:

  - SnippetRunner Code Snippets: To demonstrate new features,
    added new functionality to snpPattern

  - A new sample plugin, Empty Panel, demonstrates the usage of 
    new APIs for accessing the empty panel. The empty panel is 
    intended to be used by developers wishing to create a plugin 
    UI using third party UI frameworks.

  - Removal of ADM from the SDK. This includes the conversion of 
    existing CS5 SDK samples to use a Flash-based UI, which is a 
    possible alternative for ADM. For details, see "Creating a 
    Flash UI for Plug-ins" in "Adobe Illustrator CS6 Programmer's Guide".

  - All samples support 64bit

***********************************************************
6. Known Issues
***********************************************************

The following are known issues in this SDK. These issues will be
addressed in forthcoming SDKs:

______________________________________________________________________
* If you installed security update 896358 or Microsoft Windows Server 2003
  Service Pack 1 (SP1), you may experience broken links and missing text
  while viewing the <SDK>/docs/references/index.chm file.

  Use one of these workarounds:

  Method 1
  --------
  1. Double-click the index.chm file.
  2. In the "Open File-Security Warning" dialog box, clear the
     "Always ask before opening this file" check box.
  3. Click Open.

  Method 2
  --------
  1. Right-click the index.chm file, then click Properties.
  2. Click Unblock.
  3. Double-click the index.chm file to open the file.

  For details, see http://support.microsoft.com/kb/902225.
______________________________________________________________________


***********************************************************
7. SDK Support and Adobe Partner Programs
***********************************************************
If you require SDK support for the Illustrator CS6 SDK,
you may purchase single or multi-pack SDK support cases.
Information on purchasing SDK support cases can be found at:

  http://partners.adobe.com/public/developer/support/index.html

Information on Adobe support, in general, may be found at:

  http://www.adobe.com/support/programs/

If you are a partner who extends, markets, or sells Adobe
products or solutions, you should consider membership in
the Adobe Partner Connection Solution Partner Program.
The Solution Partner Program provides development support,
access to timely product information, as well as various
marketing benefits. To learn more about the program, point
your browser to:

  https://www.adobe.com/cfusion/partnerportal/index.cfm

_____________________________________________________________________________
Copyright 2012 Adobe Systems Incorporated. All rights reserved.

Adobe and Illustrator are registered trademarks or trademarks of Adobe
Systems Incorporated in the United States and/or other countries. Windows
is a registered trademark or trademark of Microsoft Corporation in the
United States and/or other countries. Macintosh is a trademark of Apple
Computer, Incorporated, registered in the United States and other countries.
All other brand and product names are trademarks or registered trademarks of
their respective holders.
_____________________________________________________________________________


